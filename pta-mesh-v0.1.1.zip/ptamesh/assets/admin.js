// Future: AJAX search for SKU/ASIN, barcode scan helpers
console.log('PTAMesh admin loaded');
